import React from 'react';
import './App.css';
class App extends React.Component {
  state = {
    categories: [],
    fetchedcategories: null,
    title: ''
  }
  componentDidMount() {
    const apiUrl = 'https://api.chucknorris.io/jokes/categories';
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => this.setState({categories:data})
      );
  }
  fetchByCategory( category) {
    console.log('this is:', category);
    const apiUrl = 'https://api.chucknorris.io/jokes/random?category='+category;
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => 
      this.setState({fetchedcategories:data})
      );
  }
  handleChange(event) {  
    this.setState({title: event.target.value})
    console.log(this.state.title);
  
  }
  render() {
    this.state.categories = this.state.categories.filter(cats => {
      return cats.indexOf(this.state.title.toLowerCase()) !== -1;
    });
    if(this.state.fetchedcategories!==null){
      console.log(this.state.fetchedcategories.categories[0]);
      console.log(this.state.fetchedcategories);
    console.log(this.state.fetchedcategories.value);
    return  (
      <div className="container">
       <div className="col-xs-12">
       <div className="col-xs-12"/>
       <h4>{this.state.fetchedcategories.categories[0].toUpperCase()}</h4>
        <div className="card">
           <div className="card-body">
             <h5 className="card-title">{this.state.fetchedcategories.value} </h5>
             
           </div>
         </div>
         
       </div>
      </div>
      
   );
    }
    return  (
      <div className="container">
       <div className="col-xs-12">
       <div className="col-xs-12"/>
       <h2>List of available categories.</h2>

      <label className="search-label" htmlFor="search-input">
					<input
						type="text"
						value=""
						id="search-input"
            placeholder="Search..."
            value={this.state.title} 
    onChange={this.handleChange.bind(this)}
					/>
					<i className="fa fa-search search-icon"/>
				</label>
				
		
				
			
       {this.state.categories.map((category) => (
         <div className="card">
           <div className="card-body">
             <a href="#" className="card-title" onClick={() => this.fetchByCategory(category)}>{category} </a>
             
           </div>
         </div>
       ))}
       </div>
      </div>
   );
  }
}
export default App;